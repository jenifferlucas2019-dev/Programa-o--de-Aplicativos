import React from "react";

// 1. Componente OlaMundo
function OlaMundo() {
  return (
    <div style={{ backgroundColor: "red", color: "blue", textAlign: "center" }}>
      Olá, Mundo!!
    </div>
  );
}

// 2. Componente DiaAtual
function DiaAtual() {
  return (
    <div style={{ backgroundColor: "blue", color: "white", textAlign: "center" }}>
      15
    </div>
  );
}

// 3. Componente MesAtual
function MesAtual() {
  return (
    <div style={{ backgroundColor: "green", color: "white", textAlign: "left" }}>
      03
    </div>
  );
}

// 4. Componente AnoAtual
function AnoAtual() {
  return (
    <div style={{ backgroundColor: "red", color: "yellow", textAlign: "right" }}>
      2024
    </div>
  );
}

// 5. Componente HoraAtual
function HoraAtual() {
  return (
    <div style={{
      width: "50px",
      height: "50px",
      borderRadius: "50%",
      backgroundColor: "blue",
      color: "yellow",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      20
    </div>
  );
}

// 6. Componente MinutoAtual
function MinutoAtual() {
  return (
    <div style={{
      width: "50px",
      height: "50px",
      borderRadius: "50%",
      backgroundColor: "pink",
      color: "black",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      30
    </div>
  );
}

// 7. Componente DataCompletaAtual
function DataCompletaAtual() {
  return (
    <div style={{ backgroundColor: "brown", color: "white", textAlign: "center" }}>
      15/03/2024 20:30
    </div>
  );
}

// 8. Componente OlaPessoa
function OlaPessoa({ nome }) {
  return (
    <div style={{ backgroundColor: "orange", color: "white", textAlign: "center" }}>
      Olá, {nome}!
    </div>
  );
}

// 9. Componente ListaProdutos
function ListaProdutos({ produtos }) {
  return (
    <ul style={{ backgroundColor: "purple", color: "yellow" }}>
      {produtos.map((produto, index) => (
        <li key={index}>{produto}</li>
      ))}
    </ul>
  );
}

// 10. Componente VerificarIdade
function VerificarIdade({ idade }) {
  if (idade >= 18) {
    return (
      <div style={{ backgroundColor: "green", color: "yellow" }}>
        {idade} anos, é maior de idade
      </div>
    );
  }

  return (
    <div style={{ backgroundColor: "red", color: "yellow" }}>
      {idade} anos, é menor de idade
    </div>
  );
}

// 11. Componente NumerosPares
function NumerosPares({ numeros }) {
  return (
    <ul style={{ backgroundColor: "blue", color: "yellow" }}>
      {numeros.filter((numero) => numero % 2 === 0).map((numero, index) => (
        <li key={index}>{numero}</li>
      ))}
    </ul>
  );
}

// 12. Componente NumerosImpares
function NumerosImpares({ numeros }) {
  return (
    <ul style={{ backgroundColor: "blue", color: "yellow" }}>
      {numeros.filter((numero) => numero % 2 !== 0).map((numero, index) => (
        <li key={index}>{numero}</li>
      ))}
    </ul>
  );
}

// 13. Componente Soma
function Soma({ num1, num2 }) {
  return (
    <div style={{ backgroundColor: "brown", color: "white", textAlign: "center" }}>
      Resultado: {num1 + num2}
    </div>
  );
}

// 14. Componente Subtracao
function Subtracao({ num1, num2 }) {
  return (
    <div style={{ backgroundColor: "gray", color: "white", textAlign: "center" }}>
      Resultado: {num1 - num2}
    </div>
  );
}

// 15. Componente Divisao
function Divisao({ num1, num2 }) {
  return (
    <div style={{ backgroundColor: "orange", color: "blue", textAlign: "center" }}>
      Resultado: {num2 !== 0 ? num1 / num2 : "Não é possível dividir por zero"}
    </div>
  );
}

// 16. Componente Multiplicacao
function Multiplicacao({ num1, num2 }) {
  return (
    <div style={{ backgroundColor: "orange", color: "blue", textAlign: "center" }}>
      Resultado: {num1 * num2}
    </div>
  );
}

// 17. Componente Calculadora usando switch
function Calculadora({ num1, num2, operacao }) {
  let resultado;

  switch (operacao) {
    case "soma":
      resultado = num1 + num2;
      break;
    case "subtracao":
      resultado = num1 - num2;
      break;
    case "multiplicacao":
      resultado = num1 * num2;
      break;
    case "divisao":
      resultado = num2 !== 0 ? num1 / num2 : "Não é possível dividir por zero";
      break;
    default:
      resultado = "Operação inválida";
  }

  return (
    <div style={{ backgroundColor: "green", color: "white", textAlign: "center" }}>
      Resultado: {resultado}
    </div>
  );
}

// 18. Componente TamanhoTexto
function TamanhoTexto({ texto }) {
  return (
    <div style={{ backgroundColor: "brown", color: "yellow", textAlign: "right" }}>
      Tamanho do texto: {texto.length}
    </div>
  );
}

// 19. Componente NomesOrdenados
function NomesOrdenados({ nomes }) {
  const nomesEmOrdem = [...nomes].sort((a, b) => a.localeCompare(b, "pt-BR"));

  return (
    <ol style={{ backgroundColor: "pink", color: "red" }}>
      {nomesEmOrdem.map((nome, index) => (
        <li key={index}>{nome}</li>
      ))}
    </ol>
  );
}

function App() {
  const produtos = ["Camisa", "Calça", "Tênis", "Boné"];
  const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const nomes = ["Pedro", "Ana", "Carlos", "Beatriz", "João"];

  return (
    <main>
      <h1>Exercícios ReactJS I</h1>

      <h2>1. Olá Mundo</h2>
      <OlaMundo />

      <h2>2. Dia Atual</h2>
      <DiaAtual />

      <h2>3. Mês Atual</h2>
      <MesAtual />

      <h2>4. Ano Atual</h2>
      <AnoAtual />

      <h2>5. Hora Atual</h2>
      <HoraAtual />

      <h2>6. Minuto Atual</h2>
      <MinutoAtual />

      <h2>7. Data Completa Atual</h2>
      <DataCompletaAtual />

      <h2>8. Olá Pessoa</h2>
      <OlaPessoa nome="Jeniffer" />

      <h2>9. Lista de Produtos</h2>
      <ListaProdutos produtos={produtos} />

      <h2>10. Verificar Idade</h2>
      <VerificarIdade idade={19} />
      <VerificarIdade idade={15} />

      <h2>11. Números Pares</h2>
      <NumerosPares numeros={numeros} />

      <h2>12. Números Ímpares</h2>
      <NumerosImpares numeros={numeros} />

      <h2>13. Soma</h2>
      <Soma num1={10} num2={5} />

      <h2>14. Subtração</h2>
      <Subtracao num1={10} num2={5} />

      <h2>15. Divisão</h2>
      <Divisao num1={10} num2={5} />

      <h2>16. Multiplicação</h2>
      <Multiplicacao num1={10} num2={5} />

      <h2>17. Calculadora</h2>
      <Calculadora num1={10} num2={5} operacao="soma" />
      <Calculadora num1={10} num2={5} operacao="subtracao" />
      <Calculadora num1={10} num2={5} operacao="multiplicacao" />
      <Calculadora num1={10} num2={5} operacao="divisao" />

      <h2>18. Tamanho do Texto</h2>
      <TamanhoTexto texto="Olá, mundo!" />

      <h2>19. Nomes em Ordem Alfabética</h2>
      <NomesOrdenados nomes={nomes} />
    </main>
  );
}

export default App;
